# Resign well

Three short letters: standard, shorter notice, and leaving after a difficult time. Plus what to ask for on the way out.

## What to do

1. Open START-HERE.pdf (one page).
2. Read the notes on the second page of START-HERE.pdf.
3. Open the Word file you need in letters/. Fill the yellow [BRACKETS] with your own facts. Only say what is true for you.
4. Check the list at the end of START-HERE.pdf before you send.

The Word files open in Word, Google Docs, Pages or LibreOffice.
examples/ shows finished samples. Every name and detail in them is made up.

## Folder

- letters/1-standard-resignation.docx
- letters/2-shorter-notice-ask-to-agree.docx
- letters/3-leaving-after-a-difficult-time.docx: neutral, no complaints
- examples/standard-resignation-example.docx: a finished sample with made-up people
- sources.md: the official pages behind the notes

Free draft check: the address is on START-HERE.pdf. Send us your letter before you send it.

This kit is general information, not legal advice. Rules differ by country, by US state and by contract. Check the official pages in sources.md and your own contract.

Free. No sign-up needed.
