# Sources for Resign well

Every rule, right or figure stated in this kit comes from the pages below. Read on the date shown. Rules change: if you rely on one, open the page and check it is still current.

| Where it is used | Official page | Region | Date read |
|---|---|---|---|
| Handing in your notice: check your contract; at least a week's notice after a month; written notice; notice pay; payment in lieu; garden leave (UK) | https://www.gov.uk/handing-in-your-notice | UK | 4 October 2026 |
| Resigning: problems at work first, effect on income, resigning during redundancy (UK) | https://www.acas.org.uk/resignation | UK | 4 October 2026 |
| Notice periods (UK) | https://www.acas.org.uk/notice-periods | UK | 4 October 2026 |
| Holiday: taking holiday before leaving, paid for untaken statutory leave when you leave (UK) | https://www.gov.uk/holiday-entitlement-rights | UK | 4 October 2026 |
| Final pay: normally paid everything you earned up to the point you finish (UK) | https://www.gov.uk/understanding-your-pay | UK | 4 October 2026 |
| References: no duty to give one, basic reference, request template (UK) | https://www.acas.org.uk/providing-a-job-reference | UK | 4 October 2026 |
| Reference request letter template (UK) | https://www.acas.org.uk/reference-request-letter-template | UK | 4 October 2026 |
| Last paycheck: not required immediately by federal law, some states differ (US): Department of Labor | https://www.dol.gov/general/topic/wages/lastpaycheck | US | 4 October 2026 |
| Employment ends: subject to the contract unless a protected reason applies (US): Department of Labor | https://www.dol.gov/general/topic/termination | US | 4 October 2026 |
| Free advice line for your own situation (UK) | https://www.acas.org.uk/contact | UK | 4 October 2026 |

Link check, 4 October 2026: every page above returned 200 to a scripted request, except bls.gov, careeronestop.org and dol.gov, which refuse scripted requests (403) but load in a normal browser (checked in a browser the same day).
This kit is general information, not legal advice. Rules differ by country, by US state and by contract. Check the official pages in sources.md and your own contract.

Free advice: UK, the Acas helpline (https://www.acas.org.uk/contact). US, see the Department of Labor (https://www.dol.gov) and the EEOC (https://www.eeoc.gov) pages for your situation.
