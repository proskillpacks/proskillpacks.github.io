# Sources for Reply to a job offer

Every rule, right or figure stated in this kit comes from the pages below. Read on the date shown. Rules change: if you rely on one, open the page and check it is still current.

| Where it is used | Official page | Region | Date read |
|---|---|---|---|
| Accepting an offer makes a contract; it need not be written down (UK) | https://www.gov.uk/employment-contracts-and-conditions | UK | 4 October 2026 |
| What a written statement of employment particulars must include, and when (UK) | https://www.gov.uk/employment-contracts-and-conditions/written-statement-of-employment-particulars | UK | 4 October 2026 |
| Conditional or provisional offers (UK): 'Start a new job: step by step' | https://www.gov.uk/handing-in-your-notice | UK | 4 October 2026 |
| References: asked at the final stage, after a conditional offer, with your permission (UK) | https://www.acas.org.uk/providing-a-job-reference | UK | 4 October 2026 |
| Employment ends: subject to the contract unless a protected reason applies (US): Department of Labor | https://www.dol.gov/general/topic/termination | US | 4 October 2026 |
| Free advice line for your own situation (UK) | https://www.acas.org.uk/contact | UK | 4 October 2026 |

Link check, 4 October 2026: every page above returned 200 to a scripted request, except bls.gov, careeronestop.org and dol.gov, which refuse scripted requests (403) but load in a normal browser (checked in a browser the same day).
This kit is general information, not legal advice. Rules differ by country, by US state and by contract. Check the official pages in sources.md and your own contract.

Free advice: UK, the Acas helpline (https://www.acas.org.uk/contact). US, see the Department of Labor (https://www.dol.gov) and the EEOC (https://www.eeoc.gov) pages for your situation.
