# Sources for After a hard talk with your boss or HR: write it down

This free tool states no rules. It points to these official pages.

- Free advice line (UK): https://www.acas.org.uk/contact (UK, read 4 October 2026)
- US legal protections: https://www.eeoc.gov (US, read 4 October 2026)
- US: how to file a charge (pointer only): https://www.eeoc.gov/how-file-charge-employment-discrimination (US, read 4 October 2026)
- US pay and hours: https://www.dol.gov/agencies/whd/flsa (US, read 4 October 2026)

Link check, 4 October 2026: every page above returned 200 to a scripted request, except bls.gov, careeronestop.org and dol.gov, which refuse scripted requests (403) but load in a normal browser (checked in a browser the same day).
This kit is general information, not legal advice. Rules differ by country, by US state and by contract. Check the official pages in sources.md and your own contract.
