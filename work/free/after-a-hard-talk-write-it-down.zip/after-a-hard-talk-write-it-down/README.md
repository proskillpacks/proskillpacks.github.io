# After a hard talk with your boss or HR: write it down

A one-page checklist and a short email to fill in, so what was said is on record and nobody remembers it differently.

## What to do

1. Right after the talk, fill in the checklist: when, who, what was said, what was agreed, what you are unsure of, what you will do next. Do it the same day.
2. Open follow-up-email.docx. Fill in the yellow brackets from your checklist. Keep it short. Delete any sentence that is not true for you.
3. Send it, keep a copy, and put the reply date in your diary.

## In this folder

- write-it-down-checklist.pdf: one page, print it or fill it in on screen
- follow-up-email.docx: a short email to fill in (Word, Google Docs, Pages or LibreOffice)
- EXAMPLE-follow-up-email.docx: a finished sample with made-up names
- sources.md and LICENSE.txt

Free draft check: the address is on the checklist page. Send us your email before you send it.

This kit is general information, not legal advice. Rules differ by country, by US state and by contract. Check the official pages in sources.md and your own contract.

Free. No sign-up needed.

Fuller kits for hard moments at work: proskillpacks.github.io/work/
